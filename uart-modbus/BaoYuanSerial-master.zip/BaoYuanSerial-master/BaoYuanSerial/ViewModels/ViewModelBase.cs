using ReactiveUI;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaoYuanSerial.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
    }
}
