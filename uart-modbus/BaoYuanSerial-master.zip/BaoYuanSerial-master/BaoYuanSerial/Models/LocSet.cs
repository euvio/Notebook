﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaoYuanSerial.Models
{
    public class LocSet
    {
        public string Language { get; set; } = "en-US";
    }
}
